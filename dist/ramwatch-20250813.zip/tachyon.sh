#!/usr/bin/env bash
set -euo pipefail
exec bash -c "$(curl -fsSL https://raw.githubusercontent.com/Nietzsche24-Sketch/ramwatch/main/install.sh)"
